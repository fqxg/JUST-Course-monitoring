"""Turn free text like `Computer & Information Technology Computer Science` into (faculty, department)."""
from __future__ import annotations

import re

from just.client import JustClient
from just.models import Option

ALIASES = {"cit": "70"}  # faculty shortcuts (value ids come from the JUST dropdown)


class TargetError(Exception):
    pass


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower().replace("&", " and ")).strip()


def match_options(options: list[Option], text: str) -> list[Option]:
    """Match by internal id, exact name, alias, then 'every word is (a prefix of) a word in the name'."""
    raw = text.strip()
    t = _norm(raw)
    if not t:
        return []
    by_id = [o for o in options if o.value == raw]
    if by_id:
        return by_id
    alias = ALIASES.get(t)
    if alias:
        hit = [o for o in options if o.value == alias]
        if hit:
            return hit
    exact = [o for o in options if _norm(o.label) == t]
    if exact:
        return exact
    words = set(t.split())
    out = []
    for o in options:
        label_words = _norm(o.label).split()
        if all(any(lw.startswith(w) for lw in label_words) for w in words):
            out.append(o)
    return out


async def resolve_target(client: JustClient, words: list[str]) -> tuple[Option, Option]:
    """Find the faculty/department split point. Quoted or unquoted names both work; ids work too."""
    faculties = await client.get_faculties()
    for i in range(1, len(words)):
        f_hit = match_options(faculties, " ".join(words[:i]))
        if len(f_hit) != 1:
            continue
        d_hit = match_options(await client.get_departments(f_hit[0].value), " ".join(words[i:]))
        if len(d_hit) == 1:
            return f_hit[0], d_hit[0]
    # The user may have typed a department where the faculty belongs (e.g. "Computer Science" as faculty):
    # infer the faculty if the department name is unique across the whole university.
    for k in range(len(words)):
        text = " ".join(words[k:])
        hits = [(f, d) for f in faculties for d in await client.get_departments(f.value)
                if len(match_options([d], text)) == 1]
        if len(hits) == 1:
            return hits[0]
    raise TargetError("I couldn't work out the faculty and department from that. "
                      "Use /faculties and /departments to see exact names, or just send /add.")

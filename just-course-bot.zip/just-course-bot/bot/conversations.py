"""Interactive /add flow: Faculty -> Department -> Course ID -> All/Specific section."""
from __future__ import annotations

import warnings

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (CallbackQueryHandler, CommandHandler, ContextTypes, ConversationHandler,
                          MessageHandler, filters)

from just.errors import JustError
from just.models import Option
from .handlers import (UserError, add_quick, chunk_buttons, deps, describe_error, guarded, perform_add, reply)

from telegram.warnings import PTBUserWarning

warnings.filterwarnings("ignore", message=".*per_message=False.*", category=PTBUserWarning)

FACULTY, DEPARTMENT, COURSE, SCOPE, SECTION = range(5)


@guarded
async def add_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if context.args:                       # /add COURSE FACULTY DEPARTMENT [SECTION]
        await add_quick(update, context)
        return ConversationHandler.END
    context.user_data.pop("add", None)
    try:
        facs = await deps(context).client.get_faculties()
    except JustError as e:
        await reply(update, describe_error(e))
        return ConversationHandler.END
    await reply(update, "Select Faculty:", reply_markup=chunk_buttons([(f.label, f"fac:{f.value}") for f in facs], 1))
    return FACULTY


@guarded
async def pick_faculty(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    value = q.data.split(":", 1)[1]
    client = deps(context).client
    try:
        fac = next(f for f in await client.get_faculties() if f.value == value)
        depts = await client.get_departments(value)
    except (JustError, StopIteration) as e:
        await q.edit_message_text(describe_error(e) if isinstance(e, JustError) else "Unknown faculty.")
        return ConversationHandler.END
    context.user_data["add"] = {"fac": fac}
    await q.edit_message_text(f"Faculty: {fac.label}")
    await reply(update, "Select Department:",
                reply_markup=chunk_buttons([(d.label, f"dep:{d.value}") for d in depts], 1))
    return DEPARTMENT


@guarded
async def pick_department(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    st = context.user_data.get("add")
    if not st:
        await q.edit_message_text("Session expired. Send /add again.")
        return ConversationHandler.END
    value = q.data.split(":", 1)[1]
    try:
        dept = next(d for d in await deps(context).client.get_departments(st["fac"].value) if d.value == value)
    except (JustError, StopIteration):
        await q.edit_message_text("Couldn't load that department. Send /add again.")
        return ConversationHandler.END
    st["dept"] = dept
    await q.edit_message_text(f"Department: {dept.label}")
    await reply(update, "Enter Course ID (the 7-digit Line Number, or the Course Symbol like NES202):")
    return COURSE


@guarded
async def got_course(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["add"]["course"] = update.message.text.strip()
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("All Sections", callback_data="scope:all"),
                                InlineKeyboardButton("Specific Section", callback_data="scope:one")]])
    await reply(update, "Do you want to monitor all sections or a specific section?", reply_markup=kb)
    return SCOPE


@guarded
async def pick_scope(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    if q.data == "scope:one":
        await q.edit_message_text("Monitoring: a specific section")
        await reply(update, "Enter section number:")
        return SECTION
    await q.edit_message_text("Monitoring: all sections")
    return await _finish(update, context, None)


@guarded
async def got_section(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    return await _finish(update, context, update.message.text.strip())


async def _finish(update: Update, context: ContextTypes.DEFAULT_TYPE, section: str | None) -> int:
    st = context.user_data.pop("add", None)
    if not st:
        await reply(update, "Session expired. Send /add again.")
        return ConversationHandler.END
    try:
        text = await perform_add(context, update.effective_user.id, update.effective_chat.id,
                                 st["fac"], st["dept"], st["course"], section)
        await reply(update, text)
    except UserError as e:
        await reply(update, str(e))
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("add", None)
    await reply(update, "Cancelled.")
    return ConversationHandler.END


def build_add_conversation() -> ConversationHandler:
    text = filters.TEXT & ~filters.COMMAND
    return ConversationHandler(
        entry_points=[CommandHandler("add", add_entry)],
        states={
            FACULTY: [CallbackQueryHandler(pick_faculty, pattern=r"^fac:")],
            DEPARTMENT: [CallbackQueryHandler(pick_department, pattern=r"^dep:")],
            COURSE: [MessageHandler(text, got_course)],
            SCOPE: [CallbackQueryHandler(pick_scope, pattern=r"^scope:")],
            SECTION: [MessageHandler(text, got_section)],
        },
        fallbacks=[CommandHandler("cancel", cancel), CommandHandler("add", add_entry)],
        conversation_timeout=900,
        allow_reentry=True,
    )

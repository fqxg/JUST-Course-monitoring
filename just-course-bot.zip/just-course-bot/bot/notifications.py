"""All user-facing text. Plain text only (no parse_mode) so names containing & < > are safe."""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from database.models import MonitorRow
from just.models import Section
from scheduler.monitor import Alert, CheckReport


def fmt_time(dt: datetime | None, tz: str, with_date: bool = False) -> str:
    if dt is None:
        return "never"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(ZoneInfo(tz)).strftime("%Y-%m-%d %H:%M" if with_date else "%H:%M")


def seats_word(n: int) -> str:
    return f"{n} seat" + ("" if n == 1 else "s")


def format_alert(a: Alert, tz: str = "Asia/Amman") -> str:
    s, m = a.section, a.monitor
    head = "🚨 SEAT AVAILABLE!" if a.kind == "available" else "ℹ️ SEATS CHANGED"
    lines = [head, "", f"📚 {s.course_name}", f"🆔 Course ID: {s.course_id} ({s.course_symbol})",
             f"🔢 Section: {s.section}", ""]
    if s.available == 1:
        lines.append("🪑 ONLY 1 SEAT LEFT!")
    else:
        lines.append(f"🪑 Seats Available: {s.available}")
    lines.append(f"👥 Registered: {s.registered} / {s.capacity}")
    if s.instructor and s.instructor != "غير محدد":
        lines.append(f"👤 {s.instructor}")
    lines += ["", "A seat is currently available!" if a.kind == "available" else f"Was {a.previous}, now {s.available}.",
              f"🕒 Data as of {fmt_time(a.fetched_at, tz)}"]
    return "\n".join(lines)


def availability_lines(sections: list[Section]) -> list[str]:
    out = []
    for s in sorted(sections, key=lambda x: (len(x.section), x.section)):
        tag = " (cancelled)" if s.is_cancelled else ""
        out.append(f"Section {s.section} — {seats_word(s.available)}{tag}")
    return out


def format_added(sections: list[Section], section: str | None) -> str:
    first = sections[0]
    if section is None:
        return "\n".join(["✅ Course added successfully!", "", f"📚 {first.course_name}",
                          f"🆔 {first.course_id} ({first.course_symbol})", "", "Monitoring: All Sections", "",
                          "Current availability:", "", *availability_lines(sections), "",
                          "I will notify you when availability changes."])
    s = sections[0]
    return "\n".join(["✅ Course added successfully!", "", f"📚 {s.course_name}",
                      f"🆔 {s.course_id} ({s.course_symbol})", f"🔢 Section: {s.section}", "",
                      f"🪑 Available seats: {s.available}" + (" (cancelled)" if s.is_cancelled else ""), "",
                      f"I will monitor only Section {s.section}."])


def format_list(monitors: list[MonitorRow]) -> str:
    if not monitors:
        return "📋 You are not monitoring any courses yet. Use /add."
    lines = ["📋 MONITORED COURSES", ""]
    for i, m in enumerate(monitors, 1):
        sec = f"🔢 Section: {m.specific_section}" if m.specific_section else "🔢 Sections: ALL"
        lines += [f"{i}. {m.course_name}", f"   🆔 {m.course_id} ({m.course_symbol})",
                  f"   🏫 {m.faculty}", f"   📂 {m.department}", f"   {sec}", ""]
    return "\n".join(lines).rstrip()


def format_check(report: CheckReport, tz: str) -> str:
    if not report.results:
        return "📋 You are not monitoring any courses yet. Use /add."
    lines = ["🔄 Check complete", ""]
    for r in report.results:
        m = r.monitor
        target = f"Section {m.specific_section}" if m.specific_section else "all sections"
        lines.append(f"📚 {m.course_name} ({m.course_id}) — {target}")
        if r.error:
            lines.append(f"   ⚠️ {r.error}")
        else:
            lines += [f"   {x}" for x in availability_lines(r.sections)]
            lines.append(f"   🕒 data as of {fmt_time(r.fetched_at, tz)}")
        lines.append("")
    return "\n".join(lines).rstrip()


HELP = """🎓 JUST Course Seat Monitor

I watch course sections on the JUST Course Schedule (current semester, Section Status = All) and message you the moment a section goes from 0 seats to 1 or more. I only notify on that change, so no spam.

Commands
/add – add a course (interactive: faculty → department → course → sections)
/add COURSE FACULTY DEPARTMENT [SECTION] – one-line version, e.g.
   /add NES202 "Computer & Information Technology" "Network Engineering And Security"
   /add 1752020 CIT Network Engineering and Security 1
COURSE = the 7-digit Line Number or the Course Symbol (e.g. NES202).
Leave SECTION out to monitor ALL sections.
/list – your monitored courses
/remove [COURSE] [SECTION] – stop monitoring
/check – check your courses right now
/status – bot status
/faculties – list faculties
/departments [FACULTY] – list departments
/cancel – abort the current /add"""

from __future__ import annotations

import functools
import logging
import shlex
from datetime import datetime, timezone
from types import SimpleNamespace

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ChatAction
from telegram.ext import Application, ContextTypes, ConversationHandler

from database.database import DuplicateMonitor
from just.errors import JustError, ParseError, SnapshotMissing, VerificationRequired
from just.models import Option, matches_course, normalize_section
from . import notifications as N
from .parsing import TargetError, match_options, resolve_target

log = logging.getLogger(__name__)


class UserError(Exception):
    """A problem that should be shown to the user verbatim."""


def deps(context: ContextTypes.DEFAULT_TYPE) -> SimpleNamespace:
    return SimpleNamespace(**context.application.bot_data)


async def reply(update: Update, text: str, **kw) -> None:
    chat = update.effective_chat
    for i in range(0, len(text), 4000):              # Telegram's limit is 4096 characters
        await chat.send_message(text[i:i + 4000], **(kw if i + 4000 >= len(text) else {}))


def guarded(fn):
    """Optional allow-list (ALLOWED_USER_IDS). Admins are always allowed."""
    @functools.wraps(fn)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *a, **k):
        cfg = deps(context).cfg
        user = update.effective_user
        if cfg.allowed_ids and (user is None or user.id not in (cfg.allowed_ids | cfg.admin_ids)):
            await reply(update, "⛔ You are not authorized to use this bot.")
            return ConversationHandler.END
        return await fn(update, context, *a, **k)
    return wrapper


def describe_error(e: Exception) -> str:
    if isinstance(e, SnapshotMissing):
        return f"📭 {e}"
    if isinstance(e, VerificationRequired):
        return "🛡️ JUST asked for human verification (Cloudflare) so I can't read live data right now."
    if isinstance(e, ParseError):
        return f"🧩 The JUST page didn't look as expected (site may have changed): {e}"
    if isinstance(e, JustError):
        return f"🌐 JUST website problem: {e}"
    return "⚠️ Unexpected error, please try again."


def chunk_buttons(items: list[tuple[str, str]], per_row: int = 2) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(t, callback_data=d) for t, d in items[i:i + per_row]]
            for i in range(0, len(items), per_row)]
    return InlineKeyboardMarkup(rows)


# ---------------------------------------------------------------------------------------------
# the actual "add" operation - shared by the one-line command and the interactive flow
# ---------------------------------------------------------------------------------------------
async def perform_add(context, user_id: int, chat_id: int, faculty: Option, dept: Option,
                      course_input: str, section: str | None) -> str:
    d = deps(context)
    try:
        page = await d.client.get_department_page(faculty.value, dept.value)
    except JustError as e:
        raise UserError(describe_error(e)) from e
    found = [s for s in page.sections if matches_course(s, course_input)]
    if not found:
        raise UserError(f"❌ Course '{course_input}' was not found in {faculty.label} → {dept.label} "
                        f"for the current semester. Check the Line Number / Course Symbol and the department.")
    if len({s.course_id for s in found}) > 1:
        ids = ", ".join(sorted({f"{s.course_id} ({s.course_symbol})" for s in found}))
        raise UserError(f"That matches several courses: {ids}. Please use the exact Line Number.")
    if section is not None:
        want = normalize_section(section)
        chosen = [s for s in found if normalize_section(s.section) == want]
        if not chosen:
            have = ", ".join(sorted((s.section for s in found), key=lambda x: (len(x), x)))
            raise UserError(f"❌ Section {section} doesn't exist for {found[0].course_name}. Sections: {have}")
        section = chosen[0].section
    else:
        chosen = found
    first = found[0]
    d.db.upsert_user(user_id, chat_id)
    try:
        mid = d.db.add_monitor(user_id, course_id=first.course_id, course_symbol=first.course_symbol,
                               course_name=first.course_name, faculty_id=faculty.value, faculty=faculty.label,
                               department_id=dept.value, department=dept.label, specific_section=section)
    except DuplicateMonitor:
        raise UserError("ℹ️ You are already monitoring this course" +
                        (f" (section {section})." if section else " (all sections).")) from None
    d.monitor.baseline(mid, chosen)
    return N.format_added(chosen, section)


# ---------------------------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------------------------
@guarded
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    deps(context).db.upsert_user(u.id, update.effective_chat.id)
    await reply(update, N.HELP)


@guarded
async def faculties_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        facs = await deps(context).client.get_faculties()
    except JustError as e:
        return await reply(update, describe_error(e))
    await reply(update, "🏫 Faculties:\n\n" + "\n".join(f"{i}. {f.label}" for i, f in enumerate(facs, 1))
                + "\n\nSend /departments to pick one.")


@guarded
async def departments_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    client = deps(context).client
    try:
        facs = await client.get_faculties()
        if context.args:
            hits = match_options(facs, " ".join(context.args))
            if len(hits) != 1:
                return await reply(update, "Faculty not found or ambiguous. Use /faculties.")
            return await _send_departments(update, client, hits[0])
    except JustError as e:
        return await reply(update, describe_error(e))
    await reply(update, "Select a faculty:", reply_markup=chunk_buttons([(f.label, f"dl:{f.value}") for f in facs], 1))


async def _send_departments(update: Update, client, faculty: Option):
    depts = await client.get_departments(faculty.value)
    await reply(update, f"📂 Departments of {faculty.label}:\n\n" + "\n".join(f"{i}. {d.label}" for i, d in enumerate(depts, 1)))


@guarded
async def departments_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    client = deps(context).client
    try:
        fac = next(f for f in await client.get_faculties() if f.value == q.data.split(":", 1)[1])
        await _send_departments(update, client, fac)
    except (JustError, StopIteration) as e:
        await reply(update, describe_error(e) if isinstance(e, JustError) else "Unknown faculty.")


@guarded
async def list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await reply(update, N.format_list(deps(context).db.list_monitors(update.effective_user.id)))


@guarded
async def remove_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d, uid = deps(context), update.effective_user.id
    mine = d.db.list_monitors(uid)
    if not mine:
        return await reply(update, "You are not monitoring any courses.")
    args = context.args or []
    if args:
        cands = [m for m in mine if matches_course_row(m, args[0])]
        if len(args) > 1:
            sec = args[1].lower()
            cands = [m for m in cands if (m.specific_section is None and sec == "all")
                     or (m.specific_section is not None and normalize_section(m.specific_section) == normalize_section(sec))]
        if not cands:
            return await reply(update, f"❌ '{args[0]}' isn't in your monitored list. See /list.")
        if len(cands) == 1:
            d.db.remove_monitor(uid, cands[0].id)
            return await reply(update, f"🗑️ Removed {cands[0].course_name} ({_scope(cands[0])}).")
        mine = cands
    await reply(update, "Which one do you want to remove?", reply_markup=chunk_buttons(
        [(f"{m.course_name} — {_scope(m)}", f"rm:{m.id}") for m in mine], 1))


def matches_course_row(m, text: str) -> bool:
    t = text.strip().lower()
    return t in {m.course_id.lower(), m.course_symbol.lower()}


def _scope(m) -> str:
    return f"Section {m.specific_section}" if m.specific_section else "all sections"


@guarded
async def remove_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    d, uid = deps(context), update.effective_user.id
    m = d.db.get_monitor(uid, int(q.data.split(":", 1)[1]))
    if not m or not d.db.remove_monitor(uid, m.id):
        return await q.edit_message_text("That course isn't in your list (already removed?).")
    await q.edit_message_text(f"🗑️ Removed {m.course_name} ({_scope(m)}).")


@guarded
async def check_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d = deps(context)
    await update.effective_chat.send_action(ChatAction.TYPING)
    report = await d.monitor.run_once(update.effective_user.id)   # only THIS user's courses
    await reply(update, N.format_check(report, d.cfg.timezone))


@guarded
async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d, uid = deps(context), update.effective_user.id
    tz = d.cfg.timezone
    parse = lambda v: datetime.fromisoformat(v) if v else None
    last_ok, last_err = parse(d.db.get_meta("last_success")), d.db.get_meta("last_error")
    jobs = context.application.job_queue.get_jobs_by_name("monitor") if context.application.job_queue else []
    nxt = jobs[0].next_t if jobs else None
    mine_c, mine_s = d.db.counts(uid)
    all_c, all_s = d.db.counts()
    lines = ["🤖 Bot status: running ✅", f"📡 Data source: {d.cfg.results_source}",
             f"⏱ Interval: every {d.cfg.check_interval}s",
             f"🕒 Last successful check: {N.fmt_time(last_ok, tz, True)}",
             f"⏭ Next scheduled check: {N.fmt_time(nxt, tz, True)}",
             f"📚 Your monitored courses: {mine_c} ({mine_s} sections)",
             f"🌍 All users: {all_c} courses ({all_s} sections)"]
    if last_err:
        lines.append(f"⚠️ Last error: {last_err[:200]}")
    await reply(update, "\n".join(lines))


@guarded
async def add_quick(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/add COURSE FACULTY DEPARTMENT [SECTION]"""
    try:
        try:
            tokens = shlex.split(" ".join(context.args))
        except ValueError:
            tokens = list(context.args)
        if len(tokens) < 3:
            raise UserError("Usage: /add COURSE FACULTY DEPARTMENT [SECTION]\nor just send /add for the guided flow.")
        course, rest = tokens[0], tokens[1:]
        attempts = ([(rest[:-1], rest[-1])] if len(rest) > 2 and rest[-1].isdigit() else []) + [(rest, None)]
        target, last_err = None, None
        for words, section in attempts:                      # a trailing number is the section
            try:
                target = (*await resolve_target(deps(context).client, words), section)
                break
            except TargetError as e:
                last_err = e
        if target is None:
            raise UserError(f"❌ {last_err}")
        faculty, dept, section = target
        text = await perform_add(context, update.effective_user.id, update.effective_chat.id, faculty, dept, course, section)
        await reply(update, f"🏫 {faculty.label} → {dept.label}\n\n{text}")
    except UserError as e:
        await reply(update, str(e))
    except JustError as e:
        await reply(update, describe_error(e))


# ---------------------------------------------------------------------------------------------
# admin: upload a saved JUST results page (needed while JUST enforces Cloudflare Turnstile)
# ---------------------------------------------------------------------------------------------
async def upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    d, user, doc = deps(context), update.effective_user, update.message.document
    if user is None or user.id not in d.cfg.admin_ids:
        return await reply(update, "Only admins can upload results pages.")
    if not (doc.file_name or "").lower().endswith((".html", ".htm")) or (doc.file_size or 0) > 8_000_000:
        return await reply(update, "Please send the saved JUST results page as an .html file (max 8 MB).")
    data = await (await doc.get_file()).download_as_bytearray()
    try:
        page = d.snapshots.save(bytes(data).decode("utf-8", errors="replace"))
    except VerificationRequired:
        return await reply(update, "That page is JUST's \"user couldn't be verified\" page - it has no results.")
    except JustError as e:
        return await reply(update, f"❌ Not a usable results page: {e}")
    await reply(update, f"✅ Saved: {page.semester.label} / {page.faculty.label} / {page.department.label} "
                        f"({len({s.course_id for s in page.sections})} courses, {len(page.sections)} sections).\n"
                        "Checking monitored courses now…")
    report = await d.monitor.run_once()
    await reply(update, f"Done. {report.alerts_sent} notification(s) sent.")


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Unhandled exception", exc_info=context.error)

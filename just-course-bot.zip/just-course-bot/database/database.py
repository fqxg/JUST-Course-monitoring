from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from .models import MonitorRow, SectionState


class DuplicateMonitor(Exception):
    pass


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    telegram_user_id INTEGER PRIMARY KEY,
    chat_id          INTEGER NOT NULL,
    created_at       TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS monitored_courses (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_user_id INTEGER NOT NULL REFERENCES users(telegram_user_id) ON DELETE CASCADE,
    course_id        TEXT NOT NULL,
    course_symbol    TEXT NOT NULL DEFAULT '',
    course_name      TEXT NOT NULL,
    faculty_id       TEXT NOT NULL,
    faculty          TEXT NOT NULL,
    department_id    TEXT NOT NULL,
    department       TEXT NOT NULL,
    specific_section TEXT,                       -- NULL = all sections
    section_key      TEXT NOT NULL DEFAULT '',   -- '' when specific_section IS NULL (makes UNIQUE work)
    added_at         TEXT NOT NULL,
    UNIQUE (telegram_user_id, course_id, faculty_id, department_id, section_key)
);
CREATE TABLE IF NOT EXISTS section_states (
    monitor_id         INTEGER NOT NULL REFERENCES monitored_courses(id) ON DELETE CASCADE,
    section_number     TEXT NOT NULL,
    capacity           INTEGER,
    registered         INTEGER,
    available          INTEGER NOT NULL,
    previous_available INTEGER,
    last_checked       TEXT NOT NULL,
    PRIMARY KEY (monitor_id, section_number)
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""

_MON_COLS = ("m.id, m.telegram_user_id, u.chat_id, m.course_id, m.course_symbol, m.course_name, m.faculty_id, "
             "m.faculty, m.department_id, m.department, m.specific_section, m.added_at")


class Database:
    def __init__(self, path: str):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.execute("PRAGMA foreign_keys = ON")
        if path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # ---- users ----
    def upsert_user(self, user_id: int, chat_id: int) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO users(telegram_user_id, chat_id, created_at) VALUES (?,?,?) "
                "ON CONFLICT(telegram_user_id) DO UPDATE SET chat_id = excluded.chat_id",
                (user_id, chat_id, now_iso()))

    # ---- monitors ----
    def add_monitor(self, user_id: int, *, course_id: str, course_symbol: str, course_name: str,
                    faculty_id: str, faculty: str, department_id: str, department: str,
                    specific_section: str | None) -> int:
        try:
            with self._lock, self._conn:
                cur = self._conn.execute(
                    "INSERT INTO monitored_courses(telegram_user_id, course_id, course_symbol, course_name, faculty_id,"
                    " faculty, department_id, department, specific_section, section_key, added_at)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (user_id, course_id, course_symbol, course_name, faculty_id, faculty, department_id, department,
                     specific_section, specific_section or "", now_iso()))
                return int(cur.lastrowid)
        except sqlite3.IntegrityError as e:
            raise DuplicateMonitor from e

    def _rows(self, where: str, params: tuple) -> list[MonitorRow]:
        with self._lock:
            cur = self._conn.execute(
                f"SELECT {_MON_COLS} FROM monitored_courses m JOIN users u USING (telegram_user_id) {where} ORDER BY m.id",
                params)
            return [MonitorRow(*r) for r in cur.fetchall()]

    def list_monitors(self, user_id: int | None = None) -> list[MonitorRow]:
        return self._rows("WHERE m.telegram_user_id = ?", (user_id,)) if user_id is not None else self._rows("", ())

    def get_monitor(self, user_id: int, monitor_id: int) -> MonitorRow | None:
        rows = self._rows("WHERE m.telegram_user_id = ? AND m.id = ?", (user_id, monitor_id))
        return rows[0] if rows else None

    def remove_monitor(self, user_id: int, monitor_id: int) -> bool:
        """Only ever removes a monitor that belongs to `user_id`."""
        with self._lock, self._conn:
            cur = self._conn.execute("DELETE FROM monitored_courses WHERE id = ? AND telegram_user_id = ?",
                                     (monitor_id, user_id))
            return cur.rowcount > 0

    # ---- section states ----
    def get_states(self, monitor_id: int) -> dict[str, SectionState]:
        with self._lock:
            cur = self._conn.execute(
                "SELECT monitor_id, section_number, capacity, registered, available, previous_available, last_checked "
                "FROM section_states WHERE monitor_id = ?", (monitor_id,))
            return {r[1]: SectionState(*r) for r in cur.fetchall()}

    def save_state(self, monitor_id: int, section: str, capacity: int | None, registered: int | None,
                   available: int, previous_available: int | None) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO section_states(monitor_id, section_number, capacity, registered, available,"
                " previous_available, last_checked) VALUES (?,?,?,?,?,?,?) "
                "ON CONFLICT(monitor_id, section_number) DO UPDATE SET capacity=excluded.capacity,"
                " registered=excluded.registered, available=excluded.available,"
                " previous_available=excluded.previous_available, last_checked=excluded.last_checked",
                (monitor_id, section, capacity, registered, available, previous_available, now_iso()))

    def counts(self, user_id: int | None = None) -> tuple[int, int]:
        """(monitored courses, tracked sections)"""
        with self._lock:
            w, p = ("WHERE m.telegram_user_id = ?", (user_id,)) if user_id is not None else ("", ())
            courses = self._conn.execute(f"SELECT COUNT(*) FROM monitored_courses m {w}", p).fetchone()[0]
            sections = self._conn.execute(
                f"SELECT COUNT(*) FROM section_states s JOIN monitored_courses m ON m.id = s.monitor_id {w}", p
            ).fetchone()[0]
            return courses, sections

    # ---- meta ----
    def set_meta(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT INTO meta(key, value) VALUES (?,?) "
                               "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))

    def get_meta(self, key: str) -> str | None:
        with self._lock:
            row = self._conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
            return row[0] if row else None

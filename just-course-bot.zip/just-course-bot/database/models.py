from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class MonitorRow:
    id: int
    telegram_user_id: int
    chat_id: int
    course_id: str            # JUST "Line Number" resolved at /add time
    course_symbol: str
    course_name: str
    faculty_id: str
    faculty: str
    department_id: str
    department: str
    specific_section: str | None   # None -> monitor ALL sections
    added_at: str


@dataclass(frozen=True)
class SectionState:
    monitor_id: int
    section_number: str
    capacity: int | None
    registered: int | None
    available: int
    previous_available: int | None
    last_checked: str

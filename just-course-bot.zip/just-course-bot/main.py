from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from bot import handlers as H
from bot.conversations import build_add_conversation
from bot.notifications import format_alert
from config import Config
from database.database import Database
from just.client import JustClient
from just.sources import AutoSource, LiveResultsSource, SnapshotSource
from scheduler.monitor import Alert, Monitor


def build_application(cfg: Config) -> Application:
    db = Database(cfg.database_path)
    snapshots = SnapshotSource(cfg.snapshot_dir)
    live = LiveResultsSource(cfg.just_url, cfg.http_timeout)
    source = {"snapshot": snapshots, "live": live, "auto": AutoSource(live, snapshots)}[cfg.results_source]
    client = JustClient(cfg.just_url, source, cfg.http_timeout, cfg.metadata_ttl)

    app = Application.builder().token(cfg.token).build()

    async def notify(alert: Alert) -> None:
        # each Alert carries the chat id of the ONE user who owns that monitor
        await app.bot.send_message(alert.chat_id, format_alert(alert, cfg.timezone))

    monitor = Monitor(db, client, notify, cfg.notify_on_seat_change)
    app.bot_data.update(cfg=cfg, db=db, client=client, monitor=monitor, snapshots=snapshots)

    app.add_handler(build_add_conversation())
    for name, fn in [("start", H.start), ("help", H.start), ("faculties", H.faculties_cmd),
                     ("departments", H.departments_cmd), ("list", H.list_cmd), ("remove", H.remove_cmd),
                     ("check", H.check_cmd), ("status", H.status_cmd)]:
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(CallbackQueryHandler(H.departments_button, pattern=r"^dl:"))
    app.add_handler(CallbackQueryHandler(H.remove_button, pattern=r"^rm:"))
    app.add_handler(MessageHandler(filters.Document.ALL, H.upload))
    app.add_error_handler(H.on_error)

    async def scheduled(context: ContextTypes.DEFAULT_TYPE) -> None:
        try:
            await monitor.run_once()
        except Exception:  # noqa: BLE001 - the schedule must survive anything
            logging.getLogger(__name__).exception("scheduled check failed")

    app.job_queue.run_repeating(scheduled, interval=cfg.check_interval, first=10, name="monitor")
    return app


def main() -> None:
    cfg = Config.from_env()
    logging.basicConfig(level=cfg.log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)   # httpx logs URLs incl. the bot token
    build_application(cfg).run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()

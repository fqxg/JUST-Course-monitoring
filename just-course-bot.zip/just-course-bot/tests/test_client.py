import httpx
import pytest

from just.client import JustClient
from just.errors import JustUnavailable, ParseError, SnapshotMissing, VerificationRequired
from just.sources import AutoSource, LiveResultsSource, SnapshotSource
from tests.fixtures import build_page, data_structures, sec

URL = "https://example.test/CourseSchedule/Default_En.aspx"


def fake_site(*, enforce_turnstile=False, down=False, posts=None):
    """A tiny ASP.NET-ish server: GET landing page; POST faculty/semester postbacks; POST submit -> results."""
    posts = posts if posts is not None else []

    def handler(req: httpx.Request) -> httpx.Response:
        if down:
            raise httpx.ConnectTimeout("boom")
        if req.method == "GET":
            return httpx.Response(200, text=build_page(faculty="-1", dept="-1", departments=[]))
        from urllib.parse import parse_qsl
        form = dict(parse_qsl(req.content.decode(), keep_blank_values=True))
        posts.append(form)
        fac = form["ctl00$contentPH$ddlFaculty"]
        if "ctl00$contentPH$btnSubmit" in form:
            if enforce_turnstile:
                return httpx.Response(200, text=build_page(faculty=fac, dept=form["ctl00$contentPH$ddlDept"],
                                                           results=False, verify_failed=True))
            return httpx.Response(200, text=build_page([data_structures(sec(1, 30, 28))], faculty=fac,
                                                       dept=form["ctl00$contentPH$ddlDept"]))
        return httpx.Response(200, text=build_page(faculty=fac, dept="-1"))
    return httpx.MockTransport(handler), posts


def client_for(transport, source=None):
    return JustClient(URL, source or SnapshotSource("/tmp/_unused_snap"), transport=transport, timeout=5)


async def test_metadata_semester_faculties_departments():
    transport, _ = fake_site()
    c = client_for(transport)
    assert (await c.get_current_semester()).value == "202720261"
    assert "Engineering" in [f.label for f in await c.get_faculties()]
    depts = await c.get_departments("70")
    assert [d.value for d in depts][:2] == ["171", "173"] and all(d.value != "-1" for d in depts)


async def test_website_down_raises_unavailable():
    transport, _ = fake_site(down=True)
    with pytest.raises(JustUnavailable):
        await client_for(transport).get_current_semester()


async def test_metadata_falls_back_to_cache_when_site_goes_down():
    ok, _ = fake_site()
    c = client_for(ok)
    c.ttl = 0                                            # force refresh attempts
    await c.get_faculties()
    c.transport = fake_site(down=True)[0]
    assert len(await c.get_faculties()) == 4             # stale-if-error


async def test_live_source_replays_postbacks_with_status_all():
    transport, posts = fake_site()
    page = await LiveResultsSource(URL, transport=transport).fetch("202720261", "70", "173")
    assert page.sections[0].available == 2 and page.source == "live"
    submit = posts[-1]
    assert submit["ctl00$contentPH$ddlSectionStatus"] == "-1"           # Section Status = All
    assert submit["ctl00$contentPH$ddlSemester"] == "202720261" and submit["ctl00$contentPH$ddlDept"] == "173"
    assert submit["__EVENTTARGET"] == "" and submit["__VIEWSTATE"] == "vs"


async def test_live_source_reports_turnstile_instead_of_bypassing():
    transport, _ = fake_site(enforce_turnstile=True)
    with pytest.raises(VerificationRequired):
        await LiveResultsSource(URL, transport=transport).fetch("202720261", "70", "173")


async def test_live_source_timeout():
    transport, _ = fake_site(down=True)
    with pytest.raises(JustUnavailable):
        await LiveResultsSource(URL, transport=transport).fetch("202720261", "70", "173")


async def test_snapshot_save_and_fetch(tmp_path):
    snap = SnapshotSource(tmp_path)
    saved = snap.save(build_page([data_structures(sec(3, 30, 28))]))
    assert saved.department.value == "173"
    page = await snap.fetch("202720261", "70", "173")
    assert page.sections[0].available == 2 and page.fetched_at is not None
    with pytest.raises(SnapshotMissing):
        await snap.fetch("202720261", "70", "999")


def test_snapshot_rejects_unusable_pages(tmp_path):
    snap = SnapshotSource(tmp_path)
    with pytest.raises(VerificationRequired):
        snap.save(build_page(results=False, verify_failed=True))
    with pytest.raises(ParseError):
        snap.save(build_page(results=False))             # Submit not pressed: no results table
    with pytest.raises(ParseError):
        snap.save("<html>nope</html>")


async def test_auto_source_falls_back_and_cools_down(tmp_path):
    transport, posts = fake_site(enforce_turnstile=True)
    snap = SnapshotSource(tmp_path)
    snap.save(build_page([data_structures(sec(1, 30, 29))]))
    auto = AutoSource(LiveResultsSource(URL, transport=transport), snap, cooldown=3600)
    assert (await auto.fetch("202720261", "70", "173")).source == "snapshot"
    n = len(posts)
    await auto.fetch("202720261", "70", "173")
    assert len(posts) == n                                # cool-down: no repeated live attempts


async def test_client_uses_site_semester_and_snapshot(tmp_path):
    transport, _ = fake_site()
    snap = SnapshotSource(tmp_path)
    snap.save(build_page([data_structures(sec(1, 30, 28), sec(2, 30, 30))]))
    secs = await client_for(transport, snap).get_course_sections("70", "173", "907592")
    assert [s.available for s in secs] == [2, 0]

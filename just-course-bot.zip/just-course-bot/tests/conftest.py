from __future__ import annotations

import pytest

from database.database import Database
from just.errors import JustError
from just.models import Option
from just.parser import parse_page
from tests.fixtures import DEPARTMENTS, FACULTIES, SEM, build_page


class FakeClient:
    """Stands in for JustClient: serves canned department pages (no network)."""

    def __init__(self):
        self.pages: dict[tuple[str, str], object] = {}      # (faculty, dept) -> ResultsPage | Exception
        self.calls = 0

    def set(self, courses, faculty="70", dept="173"):
        self.pages[(faculty, dept)] = parse_page(build_page(courses, faculty=faculty, dept=dept), source="fake")

    async def get_department_page(self, faculty, department):
        self.calls += 1
        v = self.pages[(faculty, department)]
        if isinstance(v, Exception):
            raise v
        return v

    async def get_faculties(self):
        return [Option(v, t) for v, t in FACULTIES]

    async def get_departments(self, faculty):
        return [Option(v, t) for v, t in DEPARTMENTS.get(faculty, [])]

    async def get_current_semester(self):
        return Option(*SEM, True)


@pytest.fixture
def db():
    d = Database(":memory:")
    yield d
    d.close()


@pytest.fixture
def client():
    return FakeClient()


@pytest.fixture
def sent():
    return []


@pytest.fixture
def notifier(sent):
    async def notify(alert):
        sent.append(alert)
    return notify


def add_monitor(db, user=1, chat=100, section=None, course="907592", fac="70", dept="173"):
    db.upsert_user(user, chat)
    return db.add_monitor(user, course_id=course, course_symbol="CS207", course_name="Data Structures",
                          faculty_id=fac, faculty="CIT", department_id=dept, department="Computer Science",
                          specific_section=section)

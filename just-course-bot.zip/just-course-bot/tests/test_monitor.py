import pytest

from just.errors import JustUnavailable
from scheduler.monitor import Monitor, classify
from tests.conftest import add_monitor
from tests.fixtures import data_structures, sec, course


def make(db, client, notifier, **kw):
    return Monitor(db, client, notifier, **kw)


@pytest.mark.parametrize("prev,cur,expected", [
    (None, 5, None),        # first sighting -> silent baseline
    (0, 0, None), (0, 2, "available"), (2, 2, None), (2, 1, None), (1, 0, None), (0, 1, "available"),
])
def test_classify_default(prev, cur, expected):
    assert classify(prev, cur) == expected


def test_classify_optional_change_notifications():
    assert classify(2, 1, notify_changes=True) == "update"
    assert classify(2, 2, notify_changes=True) is None
    assert classify(1, 0, notify_changes=True) is None


async def test_spec_sequence_notifies_only_on_zero_to_positive(db, client, notifier, sent):
    """0 -> 0 -> 2 (notify) -> 2 -> 1 -> 0 -> 1 (notify again)"""
    mid = add_monitor(db, section="3")
    m = make(db, client, notifier)
    fired = []
    for registered in [30, 30, 28, 28, 29, 30, 29]:
        client.set([data_structures(sec(3, 30, registered))])
        before = len(sent)
        await m.run_once()
        fired.append(len(sent) - before)
    # first check has no baseline (add flow normally provides it) so it stays silent
    assert fired == [0, 0, 1, 0, 0, 0, 1]
    assert [a.section.available for a in sent] == [2, 1]
    st = db.get_states(mid)["3"]
    assert (st.available, st.previous_available) == (1, 0)


async def test_no_notification_when_baseline_already_available(db, client, notifier, sent):
    mid = add_monitor(db)
    client.set([data_structures(sec(1, 30, 28))])
    m = make(db, client, notifier)
    m.baseline(mid, client.pages[("70", "173")].sections)     # what /add does
    await m.run_once(); await m.run_once()
    assert sent == []


async def test_same_seat_count_never_repeats(db, client, notifier, sent):
    mid = add_monitor(db, section="3")
    m = make(db, client, notifier)
    client.set([data_structures(sec(3, 30, 30))])
    await m.run_once()
    client.set([data_structures(sec(3, 30, 28))])
    for _ in range(5):
        await m.run_once()
    assert len(sent) == 1


async def test_specific_section_ignores_other_sections(db, client, notifier, sent):
    add_monitor(db, section="3")
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 30), sec(3, 30, 30))])
    await m.run_once()
    client.set([data_structures(sec(1, 30, 20), sec(2, 30, 10), sec(3, 30, 30))])   # 1 and 2 open up
    await m.run_once()
    assert sent == []
    client.set([data_structures(sec(1, 30, 20), sec(2, 30, 10), sec(3, 30, 29))])
    await m.run_once()
    assert [a.section.section for a in sent] == ["3"]


async def test_all_sections_notifies_each_section_independently(db, client, notifier, sent):
    add_monitor(db)
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 30), sec(3, 30, 30))])
    await m.run_once()
    client.set([data_structures(sec(1, 30, 29), sec(2, 30, 30), sec(3, 30, 28))])
    await m.run_once()
    assert sorted(a.section.section for a in sent) == ["1", "3"]
    assert [a.section.available for a in sorted(sent, key=lambda a: a.section.section)] == [1, 2]


async def test_new_section_opening_after_baseline_is_notified(db, client, notifier, sent):
    add_monitor(db)
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30))])
    await m.run_once()
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 10))])
    await m.run_once()
    assert [a.section.section for a in sent] == ["2"]


async def test_cancelled_section_with_free_capacity_never_notifies(db, client, notifier, sent):
    add_monitor(db)
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 0, status="Cancelled"))])
    await m.run_once(); await m.run_once()
    assert sent == []


async def test_multiple_users_get_only_their_own_notifications(db, client, notifier, sent):
    add_monitor(db, user=1, chat=111, course="907592")
    db.upsert_user(2, 222)
    db.add_monitor(2, course_id="908120", course_symbol="CS310", course_name="Database Systems", faculty_id="70",
                   faculty="CIT", department_id="173", department="Computer Science", specific_section=None)
    m = make(db, client, notifier)
    other = course("908120", "CS310", "Database Systems", [sec(1, 30, 30)])
    client.set([data_structures(sec(1, 30, 30)), other])
    await m.run_once()
    client.set([data_structures(sec(1, 30, 29)), other])       # only user 1's course opens
    await m.run_once()
    assert [(a.chat_id, a.monitor.course_id) for a in sent] == [(111, "907592")]


async def test_one_fetch_per_department_even_with_many_monitors(db, client, notifier):
    add_monitor(db, user=1); add_monitor(db, user=2, chat=200)
    client.set([data_structures(sec(1, 30, 30))])
    await make(db, client, notifier).run_once()
    assert client.calls == 1


async def test_failing_department_does_not_stop_the_others(db, client, notifier, sent):
    add_monitor(db, dept="173")
    add_monitor(db, user=2, chat=200, dept="176")
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30))], dept="173")
    client.set([data_structures(sec(1, 30, 30))], dept="176")
    await m.run_once()
    client.pages[("70", "173")] = JustUnavailable("timeout")
    client.set([data_structures(sec(1, 30, 29))], dept="176")
    report = await m.run_once()
    assert len(report.errors) == 1 and "timeout" in report.errors[0].error
    assert [a.chat_id for a in sent] == [200]
    assert db.get_meta("last_success") is not None


async def test_exception_in_one_monitor_is_contained(db, client, notifier, sent):
    add_monitor(db, user=1, chat=100)
    add_monitor(db, user=2, chat=200)
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30))])
    await m.run_once()
    client.set([data_structures(sec(1, 30, 29))])
    calls = []

    async def flaky(alert):
        calls.append(alert.chat_id)
        if alert.chat_id == 100:
            raise RuntimeError("telegram down")
        sent.append(alert)
    m.notify = flaky
    await m.run_once()
    assert calls == [100, 200] and [a.chat_id for a in sent] == [200]
    m.notify = notifier                      # user 1's transition was NOT lost: it is retried
    await m.run_once()
    assert [a.chat_id for a in sent] == [200, 100]


async def test_missing_course_reports_error_without_touching_state(db, client, notifier):
    mid = add_monitor(db)
    m = make(db, client, notifier)
    client.set([data_structures(sec(1, 30, 30))])
    await m.run_once()
    client.set([])
    report = await m.run_once()
    assert "not found" in report.results[0].error and db.get_states(mid)["1"].available == 0


async def test_notify_on_seat_change_option(db, client, notifier, sent):
    add_monitor(db, section="1")
    m = make(db, client, notifier, notify_on_change=True)
    for reg in (30, 28, 29, 29):
        client.set([data_structures(sec(1, 30, reg))])
        await m.run_once()
    assert [(a.kind, a.section.available) for a in sent] == [("available", 2), ("update", 1)]

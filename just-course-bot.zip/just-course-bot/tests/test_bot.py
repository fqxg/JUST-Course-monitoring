from types import SimpleNamespace

import pytest

from bot import handlers as H
from bot import notifications as N
from bot.parsing import TargetError, match_options, resolve_target
from config import Config
from just.errors import JustUnavailable
from scheduler.monitor import Alert, Monitor
from tests.fixtures import data_structures, sec


# ---------- faculty / department name resolution ----------
@pytest.mark.parametrize("words,fac,dept", [
    (["Computer", "&", "Information", "Technology", "Computer", "Science"], "70", "173"),
    (["Computer & Information Technology", "Computer Science"], "70", "173"),          # quoted
    (["cit", "software", "engineering"], "70", "176"),                                  # alias + partial
    (["70", "173"], "70", "173"),                                                       # internal ids
    (["engineering", "civil"], "20", "101"),
    (["Computer", "Science", "Computer", "Science"], "70", "173"),                      # dept typed as faculty
])
async def test_resolve_target(client, words, fac, dept):
    f, d = await resolve_target(client, words)
    assert (f.value, d.value) == (fac, dept)


async def test_resolve_target_failures(client):
    with pytest.raises(TargetError):
        await resolve_target(client, ["Atlantis", "Underwater", "Basketry"])
    with pytest.raises(TargetError):                        # "Computer" alone is ambiguous inside faculty 70
        await resolve_target(client, ["cit", "computer"])


async def test_match_options_is_case_and_ampersand_insensitive(client):
    facs = await client.get_faculties()
    assert [f.value for f in match_options(facs, "COMPUTER and information technology")] == ["70"]


# ---------- /add, /remove, /check through the real handlers (fake Telegram objects) ----------
class Chat:
    id = 100

    def __init__(self): self.out = []
    async def send_message(self, text, **kw): self.out.append(text)
    async def send_action(self, *_): pass


def make_env(db, client, sent, **cfg_kw):
    async def notify(a): sent.append(a)
    mon = Monitor(db, client, notify)
    data = dict(cfg=Config(token="x", **cfg_kw), db=db, client=client, monitor=mon)
    ctx = SimpleNamespace(application=SimpleNamespace(bot_data=data, job_queue=None), args=[], user_data={})
    return ctx, mon


def upd(user=1, chat=None):
    chat = chat or Chat()
    return SimpleNamespace(effective_user=SimpleNamespace(id=user), effective_chat=chat, callback_query=None), chat


async def run_add(ctx, args, user=1):
    ctx.args = args
    u, chat = upd(user)
    await H.add_quick(u, ctx)
    return "\n".join(chat.out)


async def test_add_all_sections_confirmation(db, client, sent):
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 30), sec(3, 30, 28))])
    ctx, _ = make_env(db, client, sent)
    out = await run_add(ctx, ["907592", "Computer & Information Technology", "Computer Science"])
    assert "✅ Course added successfully!" in out and "Data Structures" in out and "All Sections" in out
    for line in ("Section 1 — 0 seats", "Section 2 — 0 seats", "Section 3 — 2 seats"):
        assert line in out
    m = db.list_monitors(1)[0]
    assert m.specific_section is None and set(db.get_states(m.id)) == {"1", "2", "3"}


async def test_add_specific_section_via_unquoted_words_and_trailing_number(db, client, sent):
    client.set([data_structures(sec(1, 30, 30), sec(3, 30, 28))])
    ctx, _ = make_env(db, client, sent)
    out = await run_add(ctx, "907592 Computer & Information Technology Computer Science 3".split())
    assert "🔢 Section: 3" in out and "Available seats: 2" in out and "only Section 3" in out
    m = db.list_monitors(1)[0]
    assert m.specific_section == "3" and set(db.get_states(m.id)) == {"3"}


async def test_add_by_course_symbol_and_department_only_inference(db, client, sent):
    client.set([data_structures(sec(1, 30, 30))])
    ctx, _ = make_env(db, client, sent)
    out = await run_add(ctx, ["CS207", "Computer", "Science", "Computer", "Science"])   # the example from the spec
    assert "Course added" in out and "Computer & Information Technology → Computer Science" in out


@pytest.mark.parametrize("args,expect", [
    (["999999", "cit", "Computer Science"], "was not found"),
    (["907592", "cit", "Computer Science", "9"], "Section 9 doesn't exist"),
    (["907592", "Narnia", "Wardrobe"], "couldn't work out"),
    (["907592", "cit"], "Usage"),
])
async def test_add_errors(db, client, sent, args, expect):
    client.set([data_structures(sec(1, 30, 30))])
    ctx, _ = make_env(db, client, sent)
    assert expect in await run_add(ctx, args)
    assert db.list_monitors() == []


async def test_add_duplicate_and_website_down(db, client, sent):
    client.set([data_structures(sec(1, 30, 30))])
    ctx, _ = make_env(db, client, sent)
    await run_add(ctx, ["907592", "cit", "Computer Science"])
    assert "already monitoring" in await run_add(ctx, ["907592", "cit", "Computer Science"])
    assert "Course added" in await run_add(ctx, ["907592", "cit", "Computer Science", "1"])   # different config: ok
    client.pages[("70", "173")] = JustUnavailable("timeout")
    assert "timeout" in await run_add(ctx, ["907592", "cit", "Computer Science", "2"])


async def test_remove_variants(db, client, sent):
    client.set([data_structures(sec(1, 30, 30), sec(2, 30, 30))])
    ctx, _ = make_env(db, client, sent)
    await run_add(ctx, ["907592", "cit", "Computer Science"])
    await run_add(ctx, ["907592", "cit", "Computer Science", "2"])
    u, chat = upd()
    ctx.args = ["907592", "2"]
    await H.remove_cmd(u, ctx)
    assert "Removed" in chat.out[-1] and len(db.list_monitors(1)) == 1
    ctx.args = ["123456"]
    await H.remove_cmd(u, ctx)
    assert "isn't in your monitored list" in chat.out[-1]
    ctx.args = ["CS207"]                                     # symbol works, single match -> removed
    await H.remove_cmd(u, ctx)
    assert db.list_monitors(1) == []
    await H.remove_cmd(u, ctx)
    assert "not monitoring" in chat.out[-1]


async def test_check_only_covers_calling_user(db, client, sent):
    client.set([data_structures(sec(1, 30, 30))])
    ctx, _ = make_env(db, client, sent)
    await run_add(ctx, ["907592", "cit", "Computer Science"], user=1)
    await run_add(ctx, ["907592", "cit", "Computer Science"], user=2)
    u, chat = upd(user=1)
    await H.check_cmd(u, ctx)
    assert chat.out[0].count("📚") == 1


async def test_allow_list_blocks_strangers(db, client, sent):
    ctx, _ = make_env(db, client, sent, allowed_ids=frozenset({5}))
    u, chat = upd(user=99)
    await H.list_cmd(u, ctx)
    assert "not authorized" in chat.out[0]


# ---------- message formatting (spec section 9) ----------
def alert_for(avail, cap=30):
    from just.models import Section
    s = Section("907592", "CS207", "Data Structures", "3", capacity=cap, registered=cap - avail, status="Active")
    mon = SimpleNamespace()
    return Alert(1, mon, s, "available", 0)


def test_alert_text_multiple_seats():
    t = N.format_alert(alert_for(2))
    assert "🚨 SEAT AVAILABLE!" in t and "Data Structures" in t and "907592" in t and "Section: 3" in t
    assert "Seats Available: 2" in t and "Registered: 28 / 30" in t


def test_alert_text_single_seat():
    t = N.format_alert(alert_for(1))
    assert "ONLY 1 SEAT LEFT!" in t and "Registered: 29 / 30" in t

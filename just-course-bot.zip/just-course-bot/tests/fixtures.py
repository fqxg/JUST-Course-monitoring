"""Builds HTML that mirrors the structure of the real JUST results page (verified against a saved page)."""
from __future__ import annotations

from html import escape

SEM = ("202720261", "First Semester 2026-2027")
FACULTIES = [("10", "Medicine"), ("20", "Engineering"), ("70", "Computer & Information Technology"),
             ("90", "Science & Arts")]
DEPARTMENTS = {"70": [("171", "Computer Engineering"), ("173", "Computer Science"),
                      ("174", "Computer Information Systems"), ("176", "Software Engineering")],
               "20": [("101", "Civil Engineering"), ("102", "Computer Engineering")]}
HEADERS = ["الشعبة", "Days", "Time", "Hall", "Days 2", "Time 2", "Hall 2", "Seat Count", "Capacity",
           "Registered", "Instructor", "Status", "Teaching Type", "Hall Place"]
COLORS = {"Green": "color:White;background-color:Green;border-color:Black;width:10%;",
          "Yellow": "color:Black;background-color:Yellow;width:10%;",
          "Red": "color:Black;background-color:Red;width:10%;"}


def sec(number, capacity, registered, status="Active", room=60, instructor="Dr. Test"):
    color = "Red" if status == "Cancelled" else ("Green" if capacity - registered > 0 else "Yellow")
    return dict(number=str(number), capacity=capacity, registered=registered, status=status, room=room,
                color=color, instructor=instructor)


def course(line, symbol, name, sections, hours=3):
    return dict(line=line, symbol=symbol, name=name, sections=sections, hours=hours)


def _select(name, options, selected, onchange=""):
    opts = "".join(f'<option {"selected=\"selected\" " if v == selected else ""}value="{v}">{escape(t)}</option>'
                   for v, t in options)
    return f'<select name="{name}" id="{name.replace("$", "_")}" {onchange}>{opts}</select>'


def build_page(courses=None, *, semester=SEM, faculty="70", dept="173", faculties=FACULTIES,
               departments=None, results=True, verify_failed=False, drop_column=None):
    departments = departments if departments is not None else DEPARTMENTS.get(faculty, [])
    headers = [h for h in HEADERS if h != drop_column]
    rows = ""
    for c in courses or []:
        body = ""
        for s in c["sections"]:
            cells = [s["number"], "Sun Tue", "10:00**11:00", "C5021", "", "", "", str(s["room"]), str(s["capacity"]),
                     str(s["registered"]), s["instructor"], s["status"], "On Campus", "Engineering Buildings"]
            cells = [x for h, x in zip(HEADERS, cells) if h != drop_column]
            tds = f'<td style="{COLORS[s["color"]]}">{cells[0]}</td>' + "".join(f"<td>{x}</td>" for x in cells[1:])
            body += f"<tr>{tds}</tr>"
        rows += (
            '<tr align="center"><td style="width:10%;"><table id="innerTable"><tbody>'
            f'<tr><td>Line Number:</td><td>{c["line"]}</td></tr><tr><td>Course Symbol:</td><td>{c["symbol"]}</td></tr>'
            f'<tr><td>Course Name:</td><td>{escape(c["name"])}</td></tr><tr><td>Credit Hours:</td><td>{c["hours"]}</td></tr>'
            '</tbody></table></td><td><div><table class="gvSections" id="x_gvSections"><tbody>'
            "<tr>" + "".join(f"<th>{h}</th>" for h in headers) + f"</tr>{body}</tbody></table></div></td></tr>")
    grid = ('<table class="gvSchedule" id="ctl00_contentPH_gvSchedule"><tbody><tr><th>Course Information</th>'
            f"<th>Section Information</th></tr>{rows}</tbody></table>") if results else ""
    fail = "<span>The user couldn't be verified.</span>" if verify_failed else ""
    return (
        '<html><body><form id="aspnetForm" method="post" action="./Default_En.aspx">'
        '<input type="hidden" name="__VIEWSTATE" value="vs"/><input type="hidden" name="__EVENTVALIDATION" value="ev"/>'
        + _select("ctl00$contentPH$ddlSemester", [("-1", "- Select Semester -"), SEM, ("202620253", "Summer 2025-2026")],
                  semester[0])
        + _select("ctl00$contentPH$ddlFaculty", [("-1", "- Select Faculty -")] + faculties, faculty)
        + _select("ctl00$contentPH$ddlDept", [("-1", "- Select Department -")] + departments, dept)
        + _select("ctl00$contentPH$ddlSectionStatus", [("-1", "All"), ("1", "Opened"), ("2", "Closed")], "-1")
        + f'<input type="submit" name="ctl00$contentPH$btnSubmit" value="Submit"/>{fail}{grid}</form></body></html>')


def data_structures(*sections):
    return course("907592", "CS207", "Data Structures", list(sections))

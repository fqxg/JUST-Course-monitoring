import pytest

from just.errors import ParseError, VerificationRequired
from just.models import matches_course
from just.parser import parse_page, selected_option, soup_of
from tests.fixtures import build_page, course, data_structures, sec


def sections(*secs):
    return parse_page(build_page([data_structures(*secs)])).sections


def test_parses_course_and_section_fields():
    page = parse_page(build_page([data_structures(sec(1, 30, 30), sec(3, 30, 28))]))
    assert [s.section for s in page.sections] == ["1", "3"]
    s = page.sections[1]
    assert (s.course_id, s.course_symbol, s.course_name, s.credit_hours) == ("907592", "CS207", "Data Structures", 3)
    assert (s.capacity, s.registered, s.available) == (30, 28, 2)


def test_seat_calculation_and_column_meaning():
    s = sections(sec(1, 40, 38, room=1200))[0]
    assert s.room_seats == 1200          # hall size is NOT used for availability
    assert s.remaining_raw == 2 and s.available == 2


def test_overbooked_section_has_zero_available_but_negative_raw():
    s = sections(sec(1, 40, 42))[0]
    assert s.remaining_raw == -2 and s.available == 0


def test_cancelled_section_never_counts_as_available():
    s = sections(sec(1, 40, 0, status="Cancelled"))[0]      # capacity 40, registered 0 -> would look free
    assert s.is_cancelled and s.available == 0 and s.website_state == "Cancelled"


def test_row_colour_is_parsed():
    s = sections(sec(1, 30, 10), sec(2, 30, 30))
    assert [x.website_state for x in s] == ["Opened", "Closed"]


def test_current_semester_is_the_selected_option():
    page = parse_page(build_page([]))
    assert page.semester.value == "202720261" and page.semester.label.startswith("First Semester")
    other = parse_page(build_page([], semester=("202620253", "Summer 2025-2026")))
    assert other.semester.value == "202620253"          # follows whatever the site marks as selected


def test_placeholder_is_not_a_selection():
    html = build_page([], faculty="-1", dept="-1")
    assert selected_option(soup_of(html), "ctl00$contentPH$ddlFaculty") is None


def test_page_without_grid_means_no_courses():
    assert parse_page(build_page([], results=False)).sections == []


def test_course_with_no_sections():
    assert parse_page(build_page([course("1", "X1", "Empty", [])])).sections == []


def test_turnstile_rejection_is_detected():
    with pytest.raises(VerificationRequired):
        parse_page(build_page([], results=False, verify_failed=True))


def test_structure_change_missing_column_raises():
    with pytest.raises(ParseError):
        parse_page(build_page([data_structures(sec(1, 30, 30))], drop_column="Registered"))


def test_unexpected_page_raises():
    with pytest.raises(ParseError):
        parse_page("<html><body>Maintenance</body></html>")


def test_matches_course_by_line_number_or_symbol():
    s = sections(sec(1, 30, 30))[0]
    assert all(matches_course(s, w) for w in ("907592", "cs207", "CS-207", "0907592"))
    assert not matches_course(s, "907593") and not matches_course(s, "")

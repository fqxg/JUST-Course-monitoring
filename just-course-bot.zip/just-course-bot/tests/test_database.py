import pytest

from database.database import Database, DuplicateMonitor
from tests.conftest import add_monitor


def test_persists_across_restart(tmp_path):
    path = str(tmp_path / "bot.sqlite3")
    db = Database(path)
    mid = add_monitor(db, section="3")
    db.save_state(mid, "3", 30, 28, 2, 0)
    db.set_meta("last_success", "x")
    db.close()
    db2 = Database(path)
    m = db2.list_monitors(1)[0]
    assert (m.course_id, m.specific_section, m.chat_id) == ("907592", "3", 100)
    assert db2.get_states(mid)["3"].available == 2 and db2.get_meta("last_success") == "x"


def test_duplicate_detection_including_null_section(db):
    add_monitor(db)
    with pytest.raises(DuplicateMonitor):
        add_monitor(db)                      # two "all sections" monitors are duplicates
    add_monitor(db, section="3")             # all + one section are different configs
    with pytest.raises(DuplicateMonitor):
        add_monitor(db, section="3")


def test_specific_section_null_means_all(db):
    add_monitor(db)
    assert db.list_monitors(1)[0].specific_section is None


def test_users_are_isolated(db):
    a = add_monitor(db, user=1, chat=100)
    b = add_monitor(db, user=2, chat=200)
    assert [m.id for m in db.list_monitors(1)] == [a]
    assert not db.remove_monitor(2, a)       # user 2 cannot delete user 1's monitor
    assert db.remove_monitor(2, b) and [m.id for m in db.list_monitors()] == [a]


def test_remove_cascades_states_and_counts(db):
    mid = add_monitor(db)
    db.save_state(mid, "1", 30, 30, 0, None)
    db.save_state(mid, "2", 30, 29, 1, None)
    assert db.counts(1) == (1, 2)
    db.remove_monitor(1, mid)
    assert db.counts() == (0, 0)

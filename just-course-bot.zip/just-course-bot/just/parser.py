"""Pure HTML parsing for the JUST Course Schedule page (no network)."""
from __future__ import annotations

import re

from bs4 import BeautifulSoup, Tag

from .errors import ParseError, VerificationRequired
from .models import Option, ResultsPage, Section

SEMESTER = "ctl00$contentPH$ddlSemester"
FACULTY = "ctl00$contentPH$ddlFaculty"
DEPARTMENT = "ctl00$contentPH$ddlDept"
STATUS = "ctl00$contentPH$ddlSectionStatus"
SUBMIT = "ctl00$contentPH$btnSubmit"
GRID_ID = "ctl00_contentPH_gvSchedule"
VERIFY_FAILED = "couldn't be verified"  # server-side Turnstile rejection message
PLACEHOLDER = "-1"

_COLOR_STATE = {"green": "Opened", "yellow": "Closed", "red": "Cancelled"}


def _text(node: Tag | None) -> str:
    return " ".join(node.get_text(" ", strip=True).split()) if node else ""


def _int(text: str) -> int | None:
    m = re.fullmatch(r"-?\d+", text.strip())
    return int(m.group()) if m else None


def soup_of(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "html.parser")


def parse_options(soup: BeautifulSoup, select_name: str) -> list[Option]:
    sel = soup.find("select", {"name": select_name})
    if sel is None:
        return []
    return [Option(o.get("value", ""), _text(o), o.has_attr("selected")) for o in sel.find_all("option")]


def selected_option(soup: BeautifulSoup, select_name: str) -> Option | None:
    """The currently selected real option (ignores the '- Select ... -' placeholder)."""
    for o in parse_options(soup, select_name):
        if o.selected and o.value != PLACEHOLDER:
            return o
    return None


def real_options(options: list[Option]) -> list[Option]:
    return [o for o in options if o.value != PLACEHOLDER]


def form_state(soup: BeautifulSoup) -> dict[str, str]:
    """What a browser would submit for the ASP.NET form: hidden fields + each select's value."""
    data = {i["name"]: i.get("value", "") for i in soup.find_all("input", {"type": "hidden"}) if i.get("name")}
    for s in soup.find_all("select"):
        opts = s.find_all("option")
        chosen = next((o for o in opts if o.has_attr("selected")), opts[0] if opts else None)
        if chosen is not None and s.get("name"):
            data[s["name"]] = chosen.get("value", "")
    return data


def _course_info(cell: Tag) -> dict[str, str]:
    info: dict[str, str] = {}
    inner = cell.find("table")
    if inner is None:
        raise ParseError("course info table missing")
    for tr in inner.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) == 2:
            info[_text(tds[0]).rstrip(":").strip().lower()] = _text(tds[1])
    for key in ("line number", "course symbol", "course name"):
        if key not in info:
            raise ParseError(f"course info field missing: {key}")
    return info


def _sections_of(course_cell: Tag, info: dict[str, str]) -> list[Section]:
    grid = course_cell.find("table", class_="gvSections")
    if grid is None:
        return []
    rows = grid.find_all("tr")
    if not rows:
        return []
    headers = [_text(th) for th in rows[0].find_all("th")]
    idx = {h.lower(): i for i, h in enumerate(headers)}
    for required in ("capacity", "registered", "status"):
        if required not in idx:
            raise ParseError(f"section column missing: {required} (columns: {headers})")

    def cell(tds: list[str], name: str) -> str:
        i = idx.get(name)
        return tds[i] if i is not None and i < len(tds) else ""

    out: list[Section] = []
    for tr in rows[1:]:
        tds_tags = tr.find_all("td")
        if not tds_tags:
            continue
        if len(tds_tags) != len(headers):
            raise ParseError(f"section row has {len(tds_tags)} cells, expected {len(headers)}")
        tds = [_text(td) for td in tds_tags]
        style = tds_tags[0].get("style", "") or ""
        m = re.search(r"background-color:\s*(\w+)", style, re.I)
        out.append(Section(
            course_id=info["line number"],
            course_symbol=info["course symbol"],
            course_name=info["course name"],
            credit_hours=_int(info.get("credit hours", "")),
            section=tds[0],
            days=cell(tds, "days"), time=cell(tds, "time"), hall=cell(tds, "hall"),
            room_seats=_int(cell(tds, "seat count")),
            capacity=_int(cell(tds, "capacity")),
            registered=_int(cell(tds, "registered")),
            instructor=cell(tds, "instructor"),
            status=cell(tds, "status"),
            teaching_type=cell(tds, "teaching type"),
            place=cell(tds, "hall place"),
            website_state=_COLOR_STATE.get(m.group(1).lower()) if m else None,
        ))
    return out


def parse_sections(soup: BeautifulSoup) -> list[Section]:
    grid = soup.find("table", id=GRID_ID)
    if grid is None:
        return []
    sections: list[Section] = []
    for tr in grid.find_all("tr"):
        if tr.find_parent("table") is not grid or not tr.find_all("td", recursive=False):
            continue  # nested rows / header row
        cells = tr.find_all("td", recursive=False)
        info = _course_info(cells[0])
        sections.extend(_sections_of(cells[-1], info))
    return sections


def parse_page(html: str, *, source: str = "html") -> ResultsPage:
    """Parse a full page. Raises VerificationRequired / ParseError for known failure modes."""
    if VERIFY_FAILED in html:
        raise VerificationRequired("JUST rejected the search (Turnstile verification failed)")
    soup = soup_of(html)
    if soup.find("select", {"name": SEMESTER}) is None:
        raise ParseError("not a JUST course-schedule page (semester dropdown missing)")
    return ResultsPage(
        semester=selected_option(soup, SEMESTER),
        faculty=selected_option(soup, FACULTY),
        department=selected_option(soup, DEPARTMENT),
        sections=parse_sections(soup),
        source=source,
    )

"""Exceptions raised by the JUST client layer. The Telegram bot only needs to know these."""


class JustError(Exception):
    """Base class for everything that can go wrong while talking to JUST."""


class JustUnavailable(JustError):
    """Website down, timeout, or network failure."""


class ParseError(JustError):
    """The page did not look like what we expect (site structure changed / unexpected response)."""


class VerificationRequired(JustError):
    """JUST rejected the search because its Cloudflare Turnstile check was not passed."""


class SnapshotMissing(JustError):
    """No saved results page exists for the requested semester/faculty/department."""

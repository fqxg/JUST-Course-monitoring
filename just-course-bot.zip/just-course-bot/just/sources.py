"""Where results pages come from.

The JUST search button is protected by Cloudflare Turnstile, which a script cannot pass.
So there are two interchangeable sources behind one interface:

  * LiveResultsSource  - replays the browser's ASP.NET postbacks. Works only if JUST does not
                         enforce Turnstile (or grants access some other way); otherwise it raises
                         VerificationRequired.  It does NOT try to defeat the challenge.
  * SnapshotSource     - reads results pages that a person saved from their own browser
                         (after passing the challenge normally) and uploaded to the bot.
  * AutoSource         - live first, falls back to snapshots, with a cool-down after a rejection.
"""
from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol

import httpx

from . import parser as P
from .errors import JustError, JustUnavailable, ParseError, SnapshotMissing, VerificationRequired
from .models import ResultsPage

log = logging.getLogger(__name__)

HEADERS = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/120 Safari/537.36", "Accept-Language": "en"}


class ResultsSource(Protocol):
    name: str

    async def fetch(self, semester: str, faculty: str, department: str) -> ResultsPage: ...


def make_http_client(timeout: float, transport: httpx.AsyncBaseTransport | None = None) -> httpx.AsyncClient:
    return httpx.AsyncClient(headers=HEADERS, follow_redirects=True, timeout=timeout, transport=transport)


async def post_back(c: httpx.AsyncClient, url: str, html: str, *, target: str = "",
                    button: str | None = None, fields: dict[str, str] | None = None) -> str:
    """Submit the ASP.NET form exactly as the browser would (viewstate + current select values)."""
    data = P.form_state(P.soup_of(html))
    data.update(fields or {})
    data["__EVENTTARGET"] = "" if button else target
    data["__EVENTARGUMENT"] = ""
    if button:
        data[button] = "Submit"
    r = await c.post(url, data=data)
    r.raise_for_status()
    return r.text


class LiveResultsSource:
    name = "live"

    def __init__(self, url: str, timeout: float = 30, transport: httpx.AsyncBaseTransport | None = None):
        self.url, self.timeout, self.transport = url, timeout, transport

    async def fetch(self, semester: str, faculty: str, department: str) -> ResultsPage:
        try:
            async with make_http_client(self.timeout, self.transport) as c:
                r = await c.get(self.url)
                r.raise_for_status()
                html = r.text
                sel = P.selected_option(P.soup_of(html), P.SEMESTER)
                if sel is None or sel.value != semester:
                    html = await post_back(c, self.url, html, target=P.SEMESTER, fields={P.SEMESTER: semester})
                html = await post_back(c, self.url, html, target=P.FACULTY, fields={P.FACULTY: faculty})
                html = await post_back(c, self.url, html, button=P.SUBMIT,
                                       fields={P.DEPARTMENT: department, P.STATUS: P.PLACEHOLDER})  # status = All
        except httpx.TimeoutException as e:
            raise JustUnavailable("JUST website timed out") from e
        except httpx.HTTPError as e:
            raise JustUnavailable(f"JUST website unavailable: {e}") from e
        page = P.parse_page(html, source="live")
        page.fetched_at = datetime.now(timezone.utc)
        return page


class SnapshotSource:
    """Results pages saved by a person; one file per (semester, faculty, department)."""
    name = "snapshot"

    def __init__(self, directory: str | Path):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, semester: str, faculty: str, department: str) -> Path:
        safe = lambda s: re.sub(r"[^0-9A-Za-z_-]", "", s)
        return self.dir / f"{safe(semester)}_{safe(faculty)}_{safe(department)}.html"

    def save(self, html: str) -> ResultsPage:
        """Validate an uploaded page and store it, replacing the older snapshot of the same query."""
        page = P.parse_page(html, source="snapshot")  # raises VerificationRequired / ParseError
        if not (page.semester and page.faculty and page.department):
            raise ParseError("page has no semester/faculty/department selected - search first, then save it")
        if P.GRID_ID not in html:
            raise ParseError("page contains no results table - press Submit before saving the page")
        self._path(page.semester.value, page.faculty.value, page.department.value).write_text(html, encoding="utf-8")
        page.fetched_at = datetime.now(timezone.utc)
        return page

    async def fetch(self, semester: str, faculty: str, department: str) -> ResultsPage:
        path = self._path(semester, faculty, department)
        if not path.exists():
            raise SnapshotMissing(
                "No saved results page for this faculty/department in the current semester. "
                "An admin must upload one (see /help).")
        page = P.parse_page(path.read_text(encoding="utf-8"), source="snapshot")
        page.fetched_at = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return page

    def latest_semester(self) -> str | None:
        files = sorted(self.dir.glob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True)
        return files[0].name.split("_")[0] if files else None


class AutoSource:
    name = "auto"

    def __init__(self, live: LiveResultsSource, snapshot: SnapshotSource, cooldown: float = 1800):
        self.live, self.snapshot, self.cooldown = live, snapshot, cooldown
        self._blocked_until = 0.0

    async def fetch(self, semester: str, faculty: str, department: str) -> ResultsPage:
        if time.monotonic() >= self._blocked_until:
            try:
                return await self.live.fetch(semester, faculty, department)
            except VerificationRequired:
                self._blocked_until = time.monotonic() + self.cooldown
                log.warning("JUST requires verification; using snapshots for %ss", self.cooldown)
            except JustError as e:
                log.warning("live fetch failed (%s); trying snapshot", e)
        return await self.snapshot.fetch(semester, faculty, department)

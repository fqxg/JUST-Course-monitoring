from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class Option:
    """One <option> of a dropdown (semester / faculty / department)."""
    value: str
    label: str
    selected: bool = False


@dataclass(frozen=True)
class Section:
    """One row of the nested per-course "gvSections" table on the JUST schedule page.

    Verified column meaning (from a real results page):
      * course_id      -> "Line Number" (7 digits, unique per course/semester, e.g. 1752020)
      * capacity       -> enrollment cap of the section
      * registered     -> students registered
      * room_seats     -> the "Seat Count" column: physical seats of the HALL (NOT enrollment)
      * status         -> "Active" / "Cancelled"
      * website_state  -> row colour: Green=Opened, Yellow=Closed, Red=Cancelled
    """
    course_id: str
    course_symbol: str
    course_name: str
    section: str
    capacity: int | None = None
    registered: int | None = None
    credit_hours: int | None = None
    days: str = ""
    time: str = ""
    hall: str = ""
    room_seats: int | None = None
    instructor: str = ""
    status: str = ""
    teaching_type: str = ""
    place: str = ""
    website_state: str | None = None

    @property
    def is_cancelled(self) -> bool:
        return self.status.strip().lower().startswith("cancel") or self.website_state == "Cancelled"

    @property
    def remaining_raw(self) -> int | None:
        """capacity - registered (can be negative when a section is over-booked)."""
        if self.capacity is None or self.registered is None:
            return None
        return self.capacity - self.registered

    @property
    def available(self) -> int:
        """Seats a student could actually take. Cancelled / unknown / over-booked -> 0."""
        raw = self.remaining_raw
        if self.is_cancelled or raw is None:
            return 0
        return max(raw, 0)


@dataclass
class ResultsPage:
    semester: Option | None
    faculty: Option | None
    department: Option | None
    sections: list[Section] = field(default_factory=list)
    fetched_at: datetime | None = None
    source: str = "unknown"


def _norm_id(text: str) -> str:
    return re.sub(r"[^0-9a-z]", "", text.lower())


def matches_course(section: Section, wanted: str) -> bool:
    """User input may be the 7-digit Line Number or the Course Symbol (e.g. NES202)."""
    w = _norm_id(wanted)
    if not w:
        return False
    cid = _norm_id(section.course_id)
    return w in {cid, _norm_id(section.course_symbol)} or (w.isdigit() and cid.lstrip("0") == w.lstrip("0"))


def normalize_section(text: str) -> str:
    t = text.strip()
    return str(int(t)) if t.isdigit() else t.lower()

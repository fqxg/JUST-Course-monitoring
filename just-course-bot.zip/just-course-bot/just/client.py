"""High-level JUST client. The Telegram bot only talks to this class."""
from __future__ import annotations

import logging
import time

import httpx

from . import parser as P
from .errors import JustError, JustUnavailable, ParseError
from .models import Option, ResultsPage, Section, matches_course
from .sources import ResultsSource, make_http_client, post_back

log = logging.getLogger(__name__)


class JustClient:
    """Metadata (semester / faculties / departments) is read live - JUST serves it without
    verification. Results come from the injected ResultsSource."""

    def __init__(self, url: str, source: ResultsSource, timeout: float = 30, metadata_ttl: float = 6 * 3600,
                 transport: httpx.AsyncBaseTransport | None = None):
        self.url, self.source, self.timeout, self.ttl, self.transport = url, source, timeout, metadata_ttl, transport
        self._landing: tuple[float, Option | None, list[Option]] | None = None
        self._departments: dict[str, tuple[float, list[Option]]] = {}

    # ---- metadata -------------------------------------------------------------------------
    async def _load_landing(self) -> tuple[Option | None, list[Option]]:
        if self._landing and time.monotonic() - self._landing[0] < self.ttl:
            return self._landing[1], self._landing[2]
        try:
            async with make_http_client(self.timeout, self.transport) as c:
                r = await c.get(self.url)
                r.raise_for_status()
            soup = P.soup_of(r.text)
            sem = P.selected_option(soup, P.SEMESTER)
            facs = P.real_options(P.parse_options(soup, P.FACULTY))
            if sem is None or not facs:
                raise ParseError("could not find the current semester / faculty list on the JUST page")
            self._landing = (time.monotonic(), sem, facs)
            return sem, facs
        except (httpx.HTTPError, JustError) as e:
            if self._landing:  # stale-if-error
                log.warning("metadata refresh failed (%s); using cached values", e)
                return self._landing[1], self._landing[2]
            if isinstance(e, JustError):
                raise
            raise JustUnavailable(f"JUST website unavailable: {e}") from e

    async def get_current_semester(self) -> Option:
        """The semester the site itself has pre-selected - never hard-coded."""
        return (await self._load_landing())[0]  # type: ignore[return-value]

    async def get_faculties(self) -> list[Option]:
        return (await self._load_landing())[1]

    async def get_departments(self, faculty_value: str) -> list[Option]:
        cached = self._departments.get(faculty_value)
        if cached and time.monotonic() - cached[0] < self.ttl:
            return cached[1]
        try:
            async with make_http_client(self.timeout, self.transport) as c:
                r = await c.get(self.url)
                r.raise_for_status()
                html = await post_back(c, self.url, r.text, target=P.FACULTY, fields={P.FACULTY: faculty_value})
            depts = P.real_options(P.parse_options(P.soup_of(html), P.DEPARTMENT))
            self._departments[faculty_value] = (time.monotonic(), depts)
            return depts
        except httpx.HTTPError as e:
            if cached:
                return cached[1]
            raise JustUnavailable(f"JUST website unavailable: {e}") from e

    # ---- results --------------------------------------------------------------------------
    async def get_department_page(self, faculty: str, department: str) -> ResultsPage:
        """All sections of a department in the current semester, Section Status = All."""
        try:
            semester = (await self.get_current_semester()).value
        except JustError:
            semester = getattr(self.source, "latest_semester", lambda: None)()
            if not semester:
                raise
        return await self.source.fetch(semester, faculty, department)

    async def get_course_sections(self, faculty: str, department: str, course_id: str) -> list[Section]:
        page = await self.get_department_page(faculty, department)
        return [s for s in page.sections if matches_course(s, course_id)]

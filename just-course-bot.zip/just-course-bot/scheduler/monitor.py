"""Periodic availability checking + no-spam transition detection."""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Awaitable, Callable

from database.database import Database, now_iso
from database.models import MonitorRow
from just.client import JustClient
from just.errors import JustError
from just.models import ResultsPage, Section, normalize_section

log = logging.getLogger(__name__)


def classify(prev: int | None, cur: int, notify_changes: bool = False) -> str | None:
    """Decide whether a section's new seat count deserves a notification.

    prev is None  -> no baseline yet (first time we see the section): stay silent.
    0  -> >0      -> "available"   (ALWAYS notifies; this is the important transition)
    >0 -> different >0 -> "update" (only when notify_changes is enabled)
    anything else (0->0, same count, ->0) -> None
    """
    if prev is None:
        return None
    if prev == 0 and cur > 0:
        return "available"
    if notify_changes and prev > 0 and cur > 0 and cur != prev:
        return "update"
    return None


@dataclass
class Alert:
    chat_id: int
    monitor: MonitorRow
    section: Section
    kind: str                       # "available" | "update"
    previous: int
    fetched_at: datetime | None = None


@dataclass
class MonitorResult:
    monitor: MonitorRow
    sections: list[Section] = field(default_factory=list)
    error: str | None = None
    fetched_at: datetime | None = None


@dataclass
class CheckReport:
    results: list[MonitorResult] = field(default_factory=list)
    alerts_sent: int = 0

    @property
    def errors(self) -> list[MonitorResult]:
        return [r for r in self.results if r.error]


Notifier = Callable[[Alert], Awaitable[None]]


def select_sections(page: ResultsPage, monitor: MonitorRow) -> list[Section]:
    """Sections of the monitored course; only the chosen one if specific_section is set."""
    secs = [s for s in page.sections if s.course_id == monitor.course_id]
    if monitor.specific_section is not None:
        want = normalize_section(monitor.specific_section)
        secs = [s for s in secs if normalize_section(s.section) == want]
    return secs


class Monitor:
    def __init__(self, db: Database, client: JustClient, notify: Notifier, notify_on_change: bool = False):
        self.db, self.client, self.notify, self.notify_on_change = db, client, notify, notify_on_change
        self._lock = asyncio.Lock()

    async def run_once(self, user_id: int | None = None) -> CheckReport:
        """Check every monitor (or only one user's). One failing course/department never stops the rest."""
        async with self._lock:
            report = CheckReport()
            groups: dict[tuple[str, str], list[MonitorRow]] = defaultdict(list)
            for m in self.db.list_monitors(user_id):
                groups[(m.faculty_id, m.department_id)].append(m)
            any_ok = False
            for (fac, dep), monitors in groups.items():          # one fetch per department, not per course
                try:
                    page = await self.client.get_department_page(fac, dep)
                except JustError as e:
                    log.warning("fetch failed for %s/%s: %s", fac, dep, e)
                    report.results += [MonitorResult(m, error=str(e)) for m in monitors]
                    self.db.set_meta("last_error", f"{now_iso()} {e}")
                    continue
                except Exception as e:  # noqa: BLE001 - must never crash the scheduler
                    log.exception("unexpected error fetching %s/%s", fac, dep)
                    report.results += [MonitorResult(m, error=f"unexpected error: {e}") for m in monitors]
                    continue
                any_ok = True
                for m in monitors:
                    try:
                        result, sent = await self._process(m, page)
                    except Exception as e:  # noqa: BLE001
                        log.exception("error processing monitor %s", m.id)
                        result, sent = MonitorResult(m, error=f"unexpected error: {e}"), 0
                    report.results.append(result)
                    report.alerts_sent += sent
            if any_ok:
                self.db.set_meta("last_success", now_iso())
            self.db.set_meta("last_run", now_iso())
            return report

    async def _process(self, m: MonitorRow, page: ResultsPage) -> tuple[MonitorResult, int]:
        sections = select_sections(page, m)
        result = MonitorResult(m, sections=sections, fetched_at=page.fetched_at)
        if not sections:
            result.error = ("Section %s not found" % m.specific_section) if m.specific_section else \
                           "Course not found in the latest data"
            return result, 0
        states = self.db.get_states(m.id)
        baseline = bool(states)          # a section first seen AFTER the baseline counts as previously 0
        sent = 0
        for s in sections:
            old = states.get(s.section)
            prev = old.available if old else (0 if baseline else None)
            kind = classify(prev, s.available, self.notify_on_change)
            if kind:
                try:
                    await self.notify(Alert(m.chat_id, m, s, kind, prev or 0, page.fetched_at))
                    sent += 1
                except Exception:  # noqa: BLE001
                    # Do NOT advance the stored state: the transition is retried on the next check.
                    log.exception("notification failed for monitor %s section %s", m.id, s.section)
                    continue
            self.db.save_state(m.id, s.section, s.capacity, s.registered, s.available, prev)
        return result, sent

    def baseline(self, m_id: int, sections: list[Section]) -> None:
        """Record the current state right after /add so the first check does not notify."""
        for s in sections:
            self.db.save_state(m_id, s.section, s.capacity, s.registered, s.available, None)

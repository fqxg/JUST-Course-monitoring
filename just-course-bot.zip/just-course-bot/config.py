from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


def _ids(raw: str) -> frozenset[int]:
    return frozenset(int(x) for x in raw.replace(";", ",").split(",") if x.strip().isdigit())


@dataclass(frozen=True)
class Config:
    token: str
    check_interval: int = 120
    database_path: str = "data/bot.sqlite3"
    snapshot_dir: str = "data/snapshots"
    results_source: str = "snapshot"          # snapshot | live | auto
    just_url: str = "https://services.just.edu.jo/CourseSchedule/Default_En.aspx"
    http_timeout: float = 30
    metadata_ttl: float = 6 * 3600
    admin_ids: frozenset[int] = frozenset()   # may upload results pages
    allowed_ids: frozenset[int] = frozenset() # empty = everyone may use the bot
    notify_on_seat_change: bool = False       # also notify when seats go e.g. 2 -> 1
    timezone: str = "Asia/Amman"
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "Config":
        load_dotenv()
        token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        if not token or token == "YOUR_TOKEN":
            raise SystemExit("TELEGRAM_BOT_TOKEN is not set (copy .env.example to .env)")
        src = os.getenv("RESULTS_SOURCE", "snapshot").lower()
        if src not in {"snapshot", "live", "auto"}:
            raise SystemExit("RESULTS_SOURCE must be snapshot, live or auto")
        return cls(
            token=token,
            check_interval=max(30, int(os.getenv("CHECK_INTERVAL", "120"))),
            database_path=os.getenv("DATABASE_PATH", "data/bot.sqlite3"),
            snapshot_dir=os.getenv("SNAPSHOT_DIR", "data/snapshots"),
            results_source=src,
            just_url=os.getenv("JUST_URL", cls.just_url),
            http_timeout=float(os.getenv("HTTP_TIMEOUT", "30")),
            metadata_ttl=float(os.getenv("METADATA_TTL", str(6 * 3600))),
            admin_ids=_ids(os.getenv("ADMIN_USER_IDS", "")),
            allowed_ids=_ids(os.getenv("ALLOWED_USER_IDS", "")),
            notify_on_seat_change=os.getenv("NOTIFY_ON_SEAT_CHANGE", "false").lower() in {"1", "true", "yes"},
            timezone=os.getenv("TIMEZONE", "Asia/Amman"),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        )
